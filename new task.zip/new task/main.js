
document.getElementById('btnTab').addEventListener('click', this.openTab);

document.getElementById('btnTab2').addEventListener('click', this.openTab2);
document.getElementById('btnWin').addEventListener('click', this.openWin);

function openTab(ev) {
  console.log('open  tab1');
  let win = window.open('tab.html', null);
  win.onload = (ev) => {
    win.document.body.style.backgroundColor = '#999';
   
  };
}
function openTab2(ev) {
  console.log('open  tab2');
  let win = window.open('tab.html', null);
  win.onload = (ev) => {
    win.document.body.style.backgroundColor = '#999';
   
  };
}

function openWin(ev) {
  console.log('open a iframe window');
 ;
  let win = window.open(
    '',
    null,
    'popup,width=400,height=400,left=300,top=500'
  );
  win.document.write(
    '<html><head><title>Opening Url </title></head><body>Example.com</body></html>'
  );
  
}